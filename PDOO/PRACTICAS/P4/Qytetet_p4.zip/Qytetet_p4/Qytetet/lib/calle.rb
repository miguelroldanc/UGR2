#encoding: utf-8
module ModeloQytetet
  class Calle < Casilla
    attr_accessor :titulo
    
    def setTitulo(titulo)
      @titulo=titulo
    end
    
    def initialize(numeroCasilla, valor, titulo)
      super(numeroCasilla, valor, TipoCasilla::CALLE)
      setTitulo(titulo)
    end
    
    def asignarPropietario(jugador)
      @titulo.setPropietario(jugador)
    end
    
    def pagarAlquiler
      @titulo.pagarAlquiler
    end
    
    def propietarioEncarcelado
      encarcel = titulo.propietarioEncarcelado
      return encarcel
    end
    
    def tengoPropietario
      tengo = titulo.tengoPropietario
      return tengo
    end
    
    def to_s
      super.to_s + " Titulo:#{@titulo.to_s}"
    end
    private :setTitulo
  end
end
