#encoding: utf-8
module ModeloQytetet
  class Especulador < Jugador
    attr_accessor :fianza

    def self.copia(unJugador, fianza)
      especulador = super.copia(unJugador)
      especulador.convertirme(fianza)
      return especulador
    end
    
    def deboIrACarcel
      return (super.deboIrACarcel && !pagarFianza)
    end
    
    def convertirme(fianza)
      @fianza = fianza
      return self
    end
    
    def edificarCasa(titulo)
      super.edificarCasa(titulo)
    end
    
    def edificarHotel(titulo)
      super.edificarHotel(titulo)
    end
    
    def pagarFianza
      if super.tengoSaldo(Qytetet.instance.tablero.carcel.valor)
      super.modificarSaldo(-Qytetet.instance.tablero.carcel.valor)
      return true
      else
        return false
      end
    end
    
    def pagarImpuesto
      if(@casillaActual.tipo == TipoCasilla::IMPUESTO)
        @saldo = @saldo - ((@casillaActual.valor)/2)
      else
        super.pagarImpuesto
      end
    end
    
    def puedoEdificarCasa(titulo)
      edificada = false
      numCasas = titulo.numCasas
      hayEspacio = numCasas < 8
      if hayEspacio
        costeEdificarCasa = titulo.precioEdificar
        tengoSaldo = tengoSaldo(costeEdificarCasa)
        if tengoSaldo && hayEspacio
          edificada = true
        end
      end
      return edificada
    end
    
    def puedoEdificarHotel(titulo)
      edificada = false
      numCasas = titulo.numHoteles
      hayEspacio = numHoteles < 8
      if hayEspacio
        costeEdificarHotel = titulo.precioEdificar
        tengoSaldo = tengoSaldo(costeEdificarHotel)
        if tengoSaldo && hayEspacio
          edificada = true
        end
      end
      return edificada
    end
    
    def to_s
      super.to_s + " Fianza:#{@fianza}"
    end
    private :pagarFianza
    protected :initialize, :pagarImpuesto, :convertirme, :puedoEdificarCasa, :puedoEdificarHotel
  end
end
