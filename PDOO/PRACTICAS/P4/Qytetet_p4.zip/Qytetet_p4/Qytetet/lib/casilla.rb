#encoding: utf-8
require_relative "tipo_casilla"
require_relative "titulo_propiedad"
require_relative "jugador"

module ModeloQytetet
  class Casilla
    
    attr_reader :numeroCasilla, :valor, :tipo
    
    def initialize(numeroCasilla, valor, tipo)
      @numeroCasilla=numeroCasilla
      @valor=valor
      @tipo=tipo
    end
    
    def soyEdificable
      return @tipo == TipoCasilla::CALLE
    end
    
    def to_s
      "NumCasilla: #{@numeroCasilla}, Valor: #{@valor}, Tipo: #{@tipo}"
    end
  end
end
