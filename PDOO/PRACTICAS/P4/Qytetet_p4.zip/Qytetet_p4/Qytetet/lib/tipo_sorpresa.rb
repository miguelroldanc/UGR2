#encoding: utf-8
module ModeloQytetet
  module TipoSorpresa
      PAGARCOBRAR =:Pagar_cobrar
      IRACASILLA=:Ir_a_casilla
      PORCASAHOTEL=:Por_Casa_Hotel
      PORJUGADOR=:Por_jugador
      SALIRCARCEL=:Salir_carcel
      CONVERTIRME=:Convertirme
  end
end
