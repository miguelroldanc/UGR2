#encoding: utf-8
module ModeloQytetet
  class TituloPropiedad
    attr_reader :nombre, :precioCompra, :alquilerBase, :factorRevalorizacion, :hipotecaBase, :precioEdificar, :numHoteles, :numCasas, :propietario
    attr_accessor :hipotecada
    
    def initialize(nombre, precioCompra, alquilerBase, factorRevalorizacion, hipotecaBase, precioEdificar)
      @hipotecada=false 
      @numHoteles=0
      @numCasas=0
      @propietario=nil
      @nombre=nombre
      @precioCompra=precioCompra
      @alquilerBase=alquilerBase
      @factorRevalorizacion=factorRevalorizacion
      @hipotecaBase=hipotecaBase
      @precioEdificar=precioEdificar
    end
    
    def calcularCosteCancelar
      raise NotImplementedError
    end
    
    def calcularCosteHipotecar
      costeHipoteca = @hipotecaBase + @numCasas*0.5*@hipotecaBase + @numHoteles*@hipotecaBase
      return costeHipoteca
    end
    
    def calcularImporteAlquiler
      costeAlquiler = @alquilerBase + (@numCasas* 0.5 + @numHoteles*2 )
      return costeAlquiler
    end
    
    def calcularPrecioVenta
      precioVenta = @precioCompra + (@numCasas + @numHoteles) *@precioEdificar*@factorRevalorizacion
      return precioVenta
    end
    
    def cancelarHipoteca
      raise NotImplementedError
    end
    
    def cobrarAlquiler(coste)
      raise NotImplementedError
    end
    
    def edificarCasa
      @numCasas = @numCasas + 1
    end
    
    def edificarHotel
      @numHoteles = @numHoteles + 1
    end
    
    def hipotecar
      costeHipoteca = calcularCosteHipotecar
      @hipotecada=true
      return costeHipoteca
    end
    
    def pagarAlquiler
      costeAlquiler = calcularImporteAlquiler
      @propietario.modificarSaldo(-costeAlquiler)
    end
    
    def propietarioEncarcelado
      return propietario.encarcelado
    end
    
    def setHipotecada(hipotecada)
      @hipotecada=hipotecada
    end
    
    def setPropietario(propietario)
      @propietario=propietario
    end
    
    def tengoPropietario
      return !(@propietario==nil)
      
    end
    def to_s
      "Nombre: #{@nombre}, \b PrecioCompra: #{@precioCompra}, \b AlquilerBase: #{@alquilerBase}
      \b FactorRevalorizacion: #{@factorRevalorizacion}, \b HipotecaBase: #{@hipotecaBase}, 
      \b PrecioEdificar: #{@precioEdificar}, \b Hipotecada: #{@hipotecada}, \b NumCasas: #{@numCasas}, \b NumHoteles: #{@numHoteles}"
    end
    
  end
end
