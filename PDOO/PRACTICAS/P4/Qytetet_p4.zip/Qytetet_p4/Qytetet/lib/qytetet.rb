#encoding: utf-8
require_relative "tablero"
require_relative "sorpresa"
require_relative "dado"
require_relative "estado_juego"
require_relative "metodo_salir_carcel"
require_relative "jugador"
require "singleton"

module ModeloQytetet
  class Qytetet
    include Singleton
    
    @@MAX_JUGADORES=4
    @@NUM_SORPRESAS=12
    @@NUM_CASILLAS=20
    @@PRECIO_LIBERTAD=200
    @@SALDO_SALIDA=1000
    
    attr_accessor :mazo, :cartaActual, :estadoJuego
    attr_reader :tablero, :dado, :jugadorActual,
      :jugadores
    def initialize
      inicializarJuego
    end
    
    def inicializarTablero
      @tablero=Tablero.new
      @tablero.inicializar
      if @tablero.casillas.length != @@NUM_CASILLAS
        raise "No hay suficientes casillas"
      end
    end
    
    def inicializarCartasSorpresa
      @mazo = Array.new
      mazo << Sorpresa.new("Te han pillado haciendo una reforma ilegal, ¡debes ir a la carcel!", tablero.carcel.numeroCasilla, TipoSorpresa::IRACASILLA)
      mazo << Sorpresa.crearSorpresa("La juez resulta que es tu prima del Realejo, y te libra de la carcel(guarda esta carta para cuando la necesites)", TipoSorpresa::SALIRCARCEL)
      mazo << Sorpresa.new("Te has ganado una siesta, dirigite al parking", 15, TipoSorpresa::IRACASILLA)
      mazo << Sorpresa.new("A veces lo mejor es empezar desde cero, ve directo a la casilla de salida", 0, TipoSorpresa::IRACASILLA)
      mazo << Sorpresa.crearSorpresa("Ha llegado la factura de la luz, hora de pagar", TipoSorpresa::PAGARCOBRAR)
      mazo << Sorpresa.crearSorpresa("Se han equivocado con tu renta y te devuelven 750€", TipoSorpresa::PAGARCOBRAR)
      mazo << Sorpresa.crearSorpresa("El ayuntamiento te agradece tus servicios a la sociedad y decide abonarte por tus propiedades", TipoSorpresa::PORCASAHOTEL)
      mazo << Sorpresa.crearSorpresa("Al ayunutamiento no le esta gustando tu negocio, debes pagar por tus casas y hoteles", TipoSorpresa::PORCASAHOTEL)
      mazo << Sorpresa.crearSorpresa("Nadie quiere tener problemas contigo, asi que deciden hacerte un cheque con 100€", TipoSorpresa::PORJUGADOR)
      mazo << Sorpresa.crearSorpresa("Tu gestión es negativa para todos los demas, paga a cada uno 100€", TipoSorpresa::PORJUGADOR)
      mazo << Sorpresa.new("Pasas a ser un especulador y tu fianza será de 3000€", 3000, TipoSorpresa::CONVERTIRME)
      mazo << Sorpresa.new("Pasas a ser un especulador y tu fianza será de 5000€", 5000, TipoSorpresa::CONVERTIRME)
      if @mazo.length != @@NUM_SORPRESAS
        raise "El mazo no contiene cartas suficientes"
      end
      @cartaActual= @mazo.get(0)
    end
    
    def actuarSiEnCasillaEdificable
      deboPagar= @jugadorActual.deboPagarAlquiler
      if deboPagar
        @jugadorActual.pagarAlquiler
        if @jugadorActual.obtenerCapital < 1
          @estadoJuego = EstadoJuego::ALGUNJUGADORENBANCARROTA
        end
      end
      casilla = obtenerCasillaJugadorActual
      tengoPropietario = casilla.tengoPropietario
      if @estadoJuego != EstadoJuego::ALGUNJUGADORENBANCARROTA
        if tengoPropietario
          @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
        else
          @estadoJuego = EstadoJuego::JA_PUEDECOMPRAROGESTIONAR
        end
      end
    end
    
    def actuarSiEnCasillaNoEdificable
      @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      casillaActual = obtenerCasillaJugadorActual
      if casillaActual.tipo == TipoCasilla::IMPUESTO
        @jugadorActual.pagarImpuesto
      elsif casillaActual.tipo == TipoCasilla::JUEZ
        encarcelarJugador
      elsif casillaActual.tipo == TipoCasilla::SORPRESA
        siguienteSorpresa()
        @estadoJuego = EstadoJuego::JA_CONSORPRESA
      end
    end
    
    def aplicarSorpresa
      @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      if @cartaActual.tipo == TipoSorpresa::SALIRCARCEL
        @jugadorActual.cartaLibertad = @cartaActual
      elsif @cartaActual.tipo == TipoSorpresa::PAGARCOBRAR
          @jugadorActual.modificarSaldo(@cartaActual.valor)
          if @jugadorActual.obtenerCapital < 1
            @estadoJuego = EstadoJuego::ALGUNJUGADORENBANCARROTA
          end
      elsif @cartaActual.tipo == TipoSorpresa::IRACASILLA
          valor= @cartaActual.valor
          casillaCarcel = @tablero.esCasillaCarcel(valor)
          if casillaCarcel == true
            encarcelarJugador
          else
            mover(valor)
          end
      elsif @cartaActual.tipo == TipoSorpresa::PORCASAHOTEL
          cantidad = @cartaActual.valor
          numeroTotal= @jugadorActual.cuantasCasasHotelesTengo
          @jugadorActual.modificarSaldo(cantidad*numeroTotal)
          if @jugadorActual.obtenerCapital < 1
            @estadoJuego = EstadoJuego::ALGUNJUGADORENBANCARROTA
          end
      elsif @cartaActual.tipo == TipoSorpresa::PORJUGADOR
          (0..@@MAX_JUGADORES-1).each do |i|
            jugador= @jugadores.get(i)
            if (jugador < @jugadorActual) || (jugador > @jugadorActual)
              jugador.modificarSaldo(@cartaActual.valor)
            end
            if jugador.obtenerCapital < 1
              @estadoJuego= EstadoJuego::ALGUNJUGADORENBANCARROTA
            end
          end
          @jugadorActual.modificarSaldo(-@cartaActual.valor)
          if @jugadorActual.obtenerCapital < 1
            @estadoJuego = EstadoJuego::ALGUNJUGADORENBANCARROTA
          end
      elsif @cartaActual.tipo == TipoSorpresa::CONVERTIRME
        especulador = @jugadorActual.convertirme(@cartaActual.valor)
        i = @jugadores.index(@jugadorActual)
        @jugadores[i] = especulador
        @jugadorActual = especulador
      end
    end
    
    def cancelarHipoteca(numeroCasilla)
      raise NotImplementedError
    end
    
    def comprarTituloPropiedad
      comprado = @jugadorActual.comprarTituloPropiedad
      if comprado == true
        @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      end
    end
    
    def deboPagarAlquiler
      deboPagar = @jugadorActual.deboPagarAlquiler
      return deboPagar
    end
    
    def edificarCasa(numeroCasilla)
      edificada = false
      casilla = @tablero.obtenerCasillaNumero(numeroCasilla)
      titulo = casilla.titulo
      edificada = @jugadorActual.edificarCasa(titulo)
      if edificada==true
        @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      end
    end
    def edificarHotel(numeroCasilla)
      edificada = false
      casilla = @tablero.obtenerCasillaNumero(numeroCasilla)
      titulo = casilla.titulo
      edificada = @jugadorActual.edificarHotel(titulo)
      if edificada==true
        @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      end
    end
    
    def encarcelarJugador
      if (@jugadorActual.deboIrACarcel)
        casillaCarcel = @tablero.carcel
        @jugadorActual.irACarcel(casillaCarcel)
        @estadoJuego = EstadoJuego::JA_ENCARCELADO
      else
        carta= @jugadorActual.devolverCartaLibertad
        incluirAlFinal(carta)
        @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
      end
    end
    
    def getValorDado
      Dado.instance.valor
    end
    
    def hipotecarPropiedad(numeroCasilla)
      casilla = @tablero.obtenerCasillaNumero(numeroCasilla)
      titulo = casilla.titulo
      @jugadorActual.hipotecarPropiedad(titulo)
      @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
    end
    
    def inicializarJuego(nombres)
      inicializarJugadores(nombres)
      inicializarTablero
      inicializarCartasSorpresa
      salidaJugadores
    end
    
    def inicializarJugadores(nombres)
      @jugadores = Array.new
      nombres.each do |nombrejugador|
        jugador = Jugador.nuevo(nombrejugador, @@SALDO_SALIDA)
        jugadores << jugador
      end
      if (@jugadores.length < 2) || (@jugadores.length > @@MAX_JUGADORES)
        raise "El numero de jugadores es incorrecto" 
      end
      
      num_jugadores=@jugadores.length
      @jugadorActual = @jugadores.get(rand 0..num_jugadores-1)
    end
    
    def intentarSalirCarcel(metodoSalirCarcel)
      if metodoSalirCarcel == MetodoSalirCarcel::TIRANDODADO
        resultado = Dado.instance.tirar
        if resultado > 4
          @jugadorActual.encarcelado = false
        end
      elsif metodoSalirCarcel == MetodoSalirCarcel::PAGANDOLIBERTAD
        cantidad = @@PRECIO_LIBERTAD
        tengoSaldo = @jugadorActual.tengoSaldo(cantidad)
        if tengoSaldo
          @jugadorActual.encarcelado = false
          @jugadorActual.pagarLibertad(cantidad)
        end
      end
      encarcelado = @jugadorActual.encarcelado
      if encarcelado
        @estadoJuego = EstadoJuego::JA_ENCARCELADO
      else
        @estadoJuego = EstadoJuego::JA_PREPARADO
      end
    end
    
    def jugar
      desplazamiento = tirarDado
      casilla = obtenerCasillaFinal(obtenerCasillaJugadorActual, desplazamiento)
      mover(casilla)
    end
    
    def mover(numCasillaDestino)
      casillaInicial = @jugadorActual.casillaActual
      casillaFinal = @tablero.obtenerCasillaNumero(numeroCasillaDestino)
      @jugadorActual.casillaActual = casillaFinal
      if numCasillaDestino < casillaInicial.numeroCasilla
        @jugadorActual.modificarSaldo(@@SALDO_SALIDA)
      end
      if casillaFinal.soyEdificable
        @jugadorActual.actuarSiEnCasillaEdificable
      else
        @jugadorActual.actuarSiEnCasillaNoEdificable
      end
    end
    
    def obtenerCasillaJugadorActual
      @jugadorActual.casillaActual
    end
    
    def obtenerCasillasTablero
      @tablero.casillas
    end
    
    def obtenerPropiedadesJugador
      casillaspropiedad = Array.new
      @tablero.casillas each do |casilla|
          if(@jugadorActual.propiedades include? (casilla.titulo))
            casillaspropiedad << casilla.numeroCasilla
          end
      end
      return casillaspropiedad
    end
    
    def obtenerPropiedadesJugadorSegunEstadoHipoteca(estadoHipoteca)
      propiedadesSegunEstado = Array.new
      propiedadesSegunEstado = obtenerPropiedades(estadoHipoteca)
      return propiedadesSegunEstado
    end
    
    def obtenerRanking
      @jugadores = @jugadores.sort
    end
    
    def obtenerSaldoJugadorActual
      @jugadorActual.obtenerCapital
    end
    
    def salidaJugadores
      @jugadores.each do |jug|
        jug.casillaActual=tablero.get(0)
      end
      tam = @jugadores.length
      @jugadorActual= @jugadores.get(rand(1..tam))
      @estadoJuego = EstadoJuego::JA_PREPARADO
    end
    
    def siguienteJugador
      siguiente = @jugadores.index(@jugadorActual)
      siguiente = siguiente + 1
      if(siguiente == @jugadores.length)
        siguiente = 0
      end
      @jugadorActual = @jugadores.get(siguiente)
      if @jugadorActual.encarcelado
        @estadoJuego = EstadoJuego::JA_ENCARCELADOCONOPCIONDELIBERTAD
      else
        @estadoJuego = EstadoJuego::JA_PREPARADO
      end
      
    end
    
    def tirarDado
      return Dado.instance.tirar
    end
    
    def venderPropiedad(numeroCasilla)
      casilla = @tablero.obtenerCasillaNumero(numeroCasilla)
      @jugadorActual.venderPropiedad(casilla)
      @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
    end
    
    def siguienteSorpresa()
      indice= @mazo.index(@cartaActual)
      indice++
      if indice == @mazo.length-1
        indice = 0
      end
      @cartaActual = @mazo.get(indice)
    end
    
  end
  def incluirAlFinal(sorpresa)
    @mazo << sorpresa
  end
  private_method_class :inicializarJugadores, :inicializarTablero, :inicializarCartasSorpresa, :salidaJugadores, :setCartaActual, :siguienteSorpresa
end
