#encoding: utf-8
require_relative "tipo_casilla"
require_relative "casilla"
require "singleton"

module ModeloQytetet
  class Tablero
    attr_reader :casillas, :carcel
    def initialize
      inicializar
    end
    
    def to_s
      @casillas.each do|casilla|
        puts casilla.to_s
      end
    end
    def inicializar
      @casillas=Array.new
      casillas << Casilla.new(0, 100, TipoCasilla::SALIDA)
      titulo = TituloPropiedad.new("Avenida del Conocimiento", 500, 10, 150, 250, 50)
      casillas << Calle.new(1, titulo.precioCompra, titulo)
      titulo = TituloPropiedad.new("Calle Andres Segovia", 650, 15, 450, 400, 65)
      casillas << Calle.new(2, titulo.precioCompra, titulo)
      casillas << Casilla.new(3, 0, TipoCasilla::IMPUESTO)
      titulo = TituloPropiedad.new("Parada de Metro PTS", 1000, 15, 500, 400, 100)
      casillas << Calle.new(4, titulo.precioCompra, titulo)
      titulo= TituloPropiedad.new("Avenida de la Constitucion", 1000, 20, 1000, 750, 100)
      casillas << Calle.new(5, titulo.precioCompra, titulo)
      casillas << Casilla.new(6, 0, TipoCasilla::CARCEL)
      @carcel = casillas[6]
    end
    
    def esCasillaCarcel(numeroCasilla)
      return numeroCasilla == @carcel.numeroCasilla
    end
    
    def obtenerCasillaFinal(casilla, desplazamiento)
      numCasillaFinal= casilla.numeroCasilla + desplazamiento
      casillaFinal=@casillas[numCasillaFinal]
      casillaFinal
    end
    
    def obtenerCasillaNumero(numeroCasilla)
      @casillas[numeroCasilla]
    end
    
    private :inicializar
  end
end
