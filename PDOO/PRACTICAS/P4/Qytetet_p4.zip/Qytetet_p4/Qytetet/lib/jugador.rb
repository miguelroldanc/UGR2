#encoding :utf-8
require_relative "casilla"
require_relative "tipo_casilla"
require_relative "sorpresa"
require_relative "metodo_salir_carcel"
require_relative "titulo_propiedad"

module ModeloQytetet
  class Jugador
    attr_accessor :cartaLibertad, :casillaActual, :encarcelado, :propiedades, :nombre
    
    def initialize(nombre, saldo, encarcelado, cartaLibertad, propiedades)
      @nombre=nombre
      @saldo = saldo
      @encarcelado=encarcelado
      @cartaLibertad = cartaLibertad
      @propiedades=propiedades
    end
    
    def self.nuevo(nombre, saldo)
      propiedades=Array.new
      self.new(nombre,saldo,false,nil,propiedades)
    end
    
    def self.copia(otroJugador)
      self.new(otroJugador.nombre, otroJugador.saldo, otroJugador.encarcelado, otroJugador.cartaLibertad, otroJugador.propiedades)
    end
    
    def to_s
      "Nombre: #{@nombre}, saldo: #{@saldo}, carta de libertad: #{@cartaLibertad.to_s}, esta encarcelado: #{@encarcelado}, casilla actual: #{@casillaActual}, #{@propiedades.join}"
    end
    
    def <=>(otroJugador)
      otroJugador.obtenerCapital <=> obtenerCapital
    end
    
    def cancelarHipoteca(titulo)
      raise NotImplementedError
    end
    
    def comprarTituloPropiedad
      comprado = false
      costeCompra = @casillaActual.valor
      if costeCompra < @saldo
        titulo = @casillaActual.asignarPropietario(Qytetet.instance.jugadorActual)
        comprado = true
        @propiedades << titulo
        self.modificarSaldo(-costeCompra)
      end
      return comprado
    end
    
    def convertirme(fianza)
      especulador = Especulador.copia(self, fianza)
      return especulador
    end
    
    def cuantasCasasHotelesTengo
      casasHoteles = 0
      @propiedades.each do |propiedad|
        casasHoteles =+ propiedad.numCasas + propiedades.numHoteles
      end
      return casasHoteles
    end
    
    def deboIrACarcel
      return !tengoCartaLibertad
    end
    
    def deboPagarAlquiler
      titulo = @casillaActual.titulo
      esDeMiPropiedad = esDeMiPropiedad(titulo)
      if !esDeMiPropiedad
        tienePropietario = titulo.propietario
        if tienePropietario
          encarcelado = titulo.propietarioEncarcelado
          if !encarcelado
            estaHipotecada= titulo.hipotecada
          end
        end
      end
      return (!esDeMiPropiedad && tienePropietario && !encarcelado && !estaHipotecada)
    end
    
    def devolverCartaLibertad
      cartaLibre = @cartaLibertad
      @cartaLibertad = nil
      return cartaLibre
    end
    
    def edificarCasa(titulo)
      if puedoEdificarCasa
        titulo.edificarCasa
        modificarSaldo(-costeEdificarCasa)
      end
    end
    
    def edificarHotel(titulo)
      if puedoEdificarHotel
        titulo.edificarHotel
        modificarSaldo(-costeEdificarHotel)
      end
    end
    
    def eliminarDeMisPropiedades(titulo)
      if (@propiedades.esDeMiPropiedad(titulo))
        @propiedades.delete(titulo)
      end
    end
    
    def esDeMiPropiedad(titulo)
      @propiedades.include?(titulo)
    end
    
    def estoyEnCalleLibre
      raise NotImplementedError
    end
    
    def hipotecarPropiedad(titulo)
      costeHipoteca = titulo.hipotecar
      modificarSaldo(costeHipoteca)
    end
    
    def irACarcel
      @casillaActual = Qytetet.instance.tablero.carcel
      @encarcelado = true
    end
    
    def modificarSaldo(cantidad)
      @saldo = @saldo + cantidad
    end
    
    def obtenerCapital
      @saldo
    end
    
    def obtenerPropiedades(hipotecada)
      resultados = Array.new
      @propiedades.each do |prop|
        if (prop.hipotecada = hipotecada)
            resultados << prop
          end
      end
      return resultados
    end
    
    def pagarAlquiler
      @casillaActual.pagarAlquiler
    end
    
    def pagarImpuesto
      @saldo = @saldo - @casillaActual.valor
    end
    
    def pagarLibertad(cantidad)
      modificarSaldo(-cantidad)
    end
    
    def puedoEdificarCasa
      edificada = false
      numCasas = titulo.numCasas
      hayEspacio = numCasas < 4
      if hayEspacio
        costeEdificarCasa = titulo.precioEdificar
        tengoSaldo = tengoSaldo(costeEdificarCasa)
        if tengoSaldo && hayEspacio
          edificada = true
        end
      end
      return edificada
    end
    
    def puedoEdificarHotel
      edificada = false
      numCasas = titulo.numHoteles
      hayEspacio = numHoteles < 4
      if hayEspacio
        costeEdificarHotel = titulo.precioEdificar
        tengoSaldo = tengoSaldo(costeEdificarHotel)
        if tengoSaldo && hayEspacio
          edificada = true
        end
      end
      return edificada
    end
    
    def tengoCartaLibertad
      if(@cartaLibertad != nil)
        return true
      else
        return false
      end
    end
    
    def tengoSaldo(cantidad)
      return obtenerCapital > cantidad
    end
    
    def venderPropiedad(casilla)
      titulo = casilla.titulo
      eliminarDeMisPropiedades(titulo)
      titulo.propietario = nil
      precioVenta = titulo.calcularPrecioVenta
      modificarSaldo(precioVenta)
      @estadoJuego = EstadoJuego::JA_PUEDEGESTIONAR
    end
    
  end
end
