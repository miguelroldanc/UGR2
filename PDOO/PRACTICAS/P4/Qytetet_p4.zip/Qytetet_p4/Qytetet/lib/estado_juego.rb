#encoding :utf-8
module ModeloQytetet
  module EstadoJuego
      JA_CONSORPRESA = :JaconSorpresa
      ALGUNJUGADORENBANCARROTA = :AlgunJugadorenBancaRota
      JA_PUEDECOMPRAROGESTIONAR = :Ja_puedeComprarOGestionar
      JA_PUEDEGESTIONAR = :JaPuedeGestionar
      JA_PREPARADO = :JaPreparado
      JA_ENCARCELADO = :JaEncarcelado
      JA_ENCARCELADOCONOPCIONDELIBERTAD = :JaEncarceladoconOpcionALibertad
  end
end
