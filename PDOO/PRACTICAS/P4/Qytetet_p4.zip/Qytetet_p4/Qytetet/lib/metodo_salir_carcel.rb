#encoding: utf-8
module ModeloQytetet
  module MetodoSalirCarcel
      TIRANDODADO=:Tirando_dado
      PAGANDOLIBERTAD=:Pagando_libertad
  end
end
