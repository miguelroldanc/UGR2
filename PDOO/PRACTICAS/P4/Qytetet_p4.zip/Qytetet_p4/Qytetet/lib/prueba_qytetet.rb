#encoding: utf-8
require_relative "tipo_sorpresa"
require_relative "sorpresa"
require_relative "tipo_casilla"
require_relative "titulo_propiedad"
require_relative "casilla"
require_relative "tablero"
require_relative "jugador"
require_relative "qytetet"
module ModeloQytetet
  class JugadorTest
    j = Jugador.new("Miguel", 2000)
    puts j.obtenerCapital
    
    puts "Hola jugador"
  end
end