#encoding: utf-8
require_relative "tipo_sorpresa"
module ModeloQytetet
  class Sorpresa
    attr_accessor :texto, :tipo, :valor
    def initialize(texto, valor, tipo)
      @texto = texto
      @valor = valor
      @tipo = tipo
    end
    
    def self.crearSorpresa(texto, valor)
      self.new(texto, nil, valor)
    end
    def to_s
      "Texto: #{@texto} \n Valor: #{@valor} \n Tipo: #{@tipo}"
    end
    
  end
end
