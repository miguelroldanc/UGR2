#encoding: utf-8

# antes de entender este código debes entender la clase Rueda (rueda.rb)

# ----------------------------------------------------------------------------
# En Ruby la estructura diccionario nos la proporciona la clase Hash
# sus características son:
# - Un Hash es una colección de pares (key, values)
# - Sin duplicados en la key.
# - Ordenado según se insertan sus key. 
# características similares al HashMap de Java, más información en el siguiente enlace:
# http://www.ruby-doc.org/core-2.0.0/Hash.html
#

require_relative 'rueda' 

#Declaración de un Hash e introducción de elementos.
 
misRuedas = Hash.new

r1 = Rueda.new(2,2)
r2 = Rueda.new(10,5)
r3 = Rueda.new(5,10)
r4 = Rueda.new(2,4)
r5 = Rueda.new(4,2)
r6 = Rueda.new(5,10)

miPila = Array.new 
miPila << r2
miPila << r4
miPila << r6
miPilaOrdenada = miPila.sort 
misRuedas[miPilaOrdenada.at(0)] = miPilaOrdenada

miPila  = Array.new
miPila  << r4
miPila  << r5
miPila  << r1
miPilaOrdenada = miPila .sort 
misRuedas[miPilaOrdenada.at(0)] = miPilaOrdenada

miPila = Array.new
miPila << r3
miPila << r6
miPila << r1
miPilaOrdenada = miPila.sort 
misRuedas[miPilaOrdenada.at(0)] = miPilaOrdenada
 

#Imprimimos el contenido del Hash de ruedas sin ordenar.
puts "Hash sin ordenar:"
misRuedas.each  { |key, value| puts "la key es" + key.to_s + " valores : ", value.each { |i| i.to_s }}  

#Probamos el método size de la clase Set de ruby.
puts "El hash tiene #{misRuedas.size} elementos"

puts "Hash ordenadas:"
misRuedasOrdenadas = misRuedas.sort # lo convierte en array 
# para convertir un Array en un Hash
class Array
  def to_hash
    inject({}) { |m, e| m[e[0]] = e[1]; m }
  end
end

ruedasHash =  misRuedasOrdenadas.to_hash

puts "Ruedas ordenadas:"  

ruedasHash.each_pair { |key, value| puts "la key es" + key.to_s + " valores : ", value.each { |i| i.to_s } } 
  


# Prueba algunos de los metodos de la clase Hash
# Prueba las estructuras iterativas con los objetos Hash.