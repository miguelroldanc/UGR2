#encoding: utf-8

# antes de entender este código debes entender la clase Rueda (rueda.rb)

require_relative 'rueda' 
require 'set'
 

#Declaración de un Set e introducción de elementos.
 
misRuedas = Set.new

r1 = Rueda.new(2,2) 
misRuedas << (Rueda.new(10,5))
misRuedas << (Rueda.new(5,10))
misRuedas << (Rueda.new(2,4))
misRuedas << (Rueda.new(4,2))
misRuedas << r1
misRuedas << (Rueda.new(5,10))
misRuedas << r1

# Ordenamos el Set de ruedas, según el orden definido en la clase Rueda  (<=>)
misRuedasOrdenadas = misRuedas.sort 

#Imprimimos el contenido del Set de ruedas sin ordenar.
puts "Set sin ordenar:"
misRuedas.each { |rueda| puts rueda.to_s  }

#Probamos el método size de la clase Set de ruby.
puts "El set tiene #{misRuedas.size} elementos"

#Imprimimos el contenido del Set de ruedas ordenado.
puts "Set Ordenado:" 
misRuedasOrdenadas.each { |rueda| puts rueda.to_s  }
 

#Modificamos una de las ruedas ¿Qué ocurre?
r1.grosor=7
#Imprimimos el contenido del Set de ruedas modificado.
puts "Set modificado :"
misRuedas.each { |rueda| puts rueda.to_s  }

# ¿Qué ocurre con el Set ordenado?
puts "Set ordenado modificado :" 
misRuedasOrdenadas.each { |rueda| puts rueda.to_s  }

#Deordenamos el Set inicial ¿Qué ocurre?

#Usamos el select
misRuedasSeleccionadas= misRuedas.select { |r| r.diametro < 5 }
puts "Ruedas seleccionadas :"
misRuedasSeleccionadas.each { |rueda| puts rueda.to_s  }

# Prueba alguno de los métodos que nos proporciona la clase Set
# Prueba la estructuras iterativas con lo objetos set.
 
